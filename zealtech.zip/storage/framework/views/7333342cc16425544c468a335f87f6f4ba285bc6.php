<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta content="width=device-width, initial-scale=1.0" name="viewport" />

        <title>Zealtech BD | <?php echo $__env->yieldContent('title'); ?></title>
        <meta content="" name="description" />
        <meta content="" name="keywords" />

        <!-- Favicons -->
        <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon" />
        <link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon" />

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet" />

        <!-- Vendor CSS Files -->
        
        <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('vendor/remixicon/remixicon.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">

        <?php echo $__env->yieldPushContent('user-css'); ?>

        <!-- Template Main CSS File -->
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />

        <!-- =======================================================
  * Template Name: Vesperr - v4.0.1
  * Template URL: https://bootstrapmade.com/vesperr-free-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
    </head>

    <body>
        <div id="loader-wrapper">
            <div class="loader-inner">
                <div class="loader"></div>
            </div>
        </div>
        <!-- ======= Header ======= -->
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header -->
        
        <!-- #main -->
        <?php echo $__env->yieldContent('user-content'); ?>
        <!-- End #main -->

        <!-- ======= Footer ======= -->
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Footer -->

        <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

        <!-- Vendor JS Files -->
        <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/glightbox/js/glightbox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/php-email-form/validate.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/purecounter/purecounter.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/swiper/swiper-bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.lazy.min.js')); ?>"></script>

        <script>
            $(window).on('load', function () {
               $('#loader-wrapper').fadeOut();
            });
    
            $(function() {
                $('.lazy').Lazy();
            });
        </script>
        <!-- Template Main JS File -->
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('user-js'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\zealtech\resources\views/layouts/user-master.blade.php ENDPATH**/ ?>