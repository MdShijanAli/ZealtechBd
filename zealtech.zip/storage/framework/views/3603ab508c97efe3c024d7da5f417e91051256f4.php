
<?php $__env->startSection('title', 'Portfolio'); ?>
<?php $__env->startSection('user-content'); ?>
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Our Portfolios</h2>
            <ol>
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li>Portfolio</li>
            </ol>
        </div>
    </div>
</section>
<section id="portfolio" class="portfolio mt-2">
    <div class="container">
        <div class="row" data-aos="fade-up" data-aos-delay="200">
            <div class="col-lg-12 d-flex justify-content-center">
                <ul id="portfolio-flters">
                    <li data-filter="*" class="filter-active">All</li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-filter=".<?php echo e($item->name); ?>"><?php echo e($item->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="400">
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 portfolio-item <?php echo e($item->category->name); ?>">
                <div class="portfolio-wrap">
                    <img class="w-100" src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt="" />
                    <div class="portfolio-info">
                        <h4><?php echo e($item->name); ?></h4>
                        <div class="portfolio-links">
                            <a href="<?php echo e(asset($item->image)); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 1"><i class="fa fa-eye"></i></a>
                            <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zealtech\resources\views/pages/portfolio.blade.php ENDPATH**/ ?>