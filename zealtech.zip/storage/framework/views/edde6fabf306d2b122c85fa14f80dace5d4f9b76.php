
<?php $__env->startSection('title', 'Our Gallery'); ?>
<?php $__env->startSection('user-content'); ?>
<section id="gallery" class="portfolio UserPage">
    <div class="container">
        <div class="section-title">
            <h2>Our Gallery</h2>
            <p class="mb-3">Lorem ipsum dolor sit amet consectetur adipisicing.</p>
        </div>
        <div class="row portfolio-container">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 portfolio-item">
                <div class="portfolio-wrap">
                    <img src="<?php echo e(asset($gallery->image)); ?>" class="img-fluid" alt="" />
                    <div class="portfolio-info">
                        <h4><?php echo e(Str::limit($gallery->title, 25)); ?></h4>
                        <div class="portfolio-links">
                            <a href="<?php echo e(asset($gallery->image)); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="<?php echo e($gallery->title); ?>"><i class="fa fa-eye"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zealtech\resources\views/pages/gallery.blade.php ENDPATH**/ ?>