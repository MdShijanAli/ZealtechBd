
<?php $__env->startSection('title', '<?php echo e($page->name); ?>'); ?>
<?php $__env->startSection('user-content'); ?>
<section id="more-services" class="more-services UserPage">
    <div class="container">
        <div class="section-title">
            <h2><?php echo e($page->title); ?></h2>
            <p class="mb-3"><?php echo e($page->sub_title); ?></p>
            <div class="text-start">
                <?php echo $page->content; ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zealtech\resources\views/pages/newPage.blade.php ENDPATH**/ ?>