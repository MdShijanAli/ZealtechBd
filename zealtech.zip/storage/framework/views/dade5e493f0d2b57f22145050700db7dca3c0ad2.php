<header id="header" class="sticky-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

    <div class="logo">
        <h1><a href="<?php echo e(route('home')); ?>">ZealtechStudio</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="img/logo.png" alt="" class="img-fluid"></a>-->
    </div>

    <nav id="navbar" class="navbar">
        <ul>
        <li><a class="nav-link scrollto active" href="<?php echo e(route('home')); ?>">Home</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('home')); ?>#about">About</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('service')); ?>">Services</a></li>
        <li><a class="nav-link scrollto " href="<?php echo e(route('portfolios')); ?>">Portfolio</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('team')); ?>">Team</a></li>
        
        <li><a class="nav-link scrollto" href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
        <li class="dropdown"><a href="#"><span>Other Page</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li><a href="<?php echo e(route('other-page', $page->slug)); ?>"><?php echo e($page->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li><a href="#">Drop Down 1</a></li>
                    <li><a href="#">Drop Down 2</a></li>
                <?php endif; ?>
            </ul>
        </li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('contact')); ?>">Contact</a></li>
        
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
    </nav><!-- .navbar -->

    </div>
</header><?php /**PATH C:\laragon\www\zealtech\resources\views/partials/header.blade.php ENDPATH**/ ?>