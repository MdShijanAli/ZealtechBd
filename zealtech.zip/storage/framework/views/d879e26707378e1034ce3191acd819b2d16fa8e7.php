
<?php $__env->startSection('title', 'Service'); ?>
<?php $__env->startSection('user-content'); ?>
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Our Services</h2>
            <ol>
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li>Service</li>
            </ol>
        </div>
    </div>
</section>
<section id="more-services" class="more-services">
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 d-flex align-items-stretch mt-3">
                <div class="card" style="background-image: url('<?php echo e(asset($service->image)); ?>');">
                    <div class="card-body">
                        <h5 class="card-title"><a href=""><?php echo e($service->name); ?></a></h5>
                        <div>
                            <?php echo Str::limit($service->details, 250); ?>

                        </div>
                        <div class="read-more">
                            <a href="<?php echo e(route('single-service', $service->slug)); ?>"><i class="bi bi-arrow-right"></i> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>  
            <div class="col-md-6 d-flex align-items-stretch">
                <div class="card" style="background-image: url('img/more-services-1.jpg');" data-aos="fade-up">
                    <div class="card-body">
                        <h5 class="card-title"><a href="">Lobira Duno</a></h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur elit, sed do eiusmod tempor ut labore et dolore magna aliqua.</p>
                        <div class="read-more">
                            <a href="#"><i class="bi bi-arrow-right"></i> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zealtech\resources\views/pages/service.blade.php ENDPATH**/ ?>