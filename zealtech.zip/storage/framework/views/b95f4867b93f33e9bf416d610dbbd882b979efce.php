<section class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="footcont ">
                    <h3 class="text-light">ZealtechStudio</h3>
                    <p class="pt-2 text-white"> <?php echo e($company->about); ?> </p>
                </div>
            </div>
            <div class="col-md-2 col-sm-6 mb-4">
                <span class="text-white border-bottom">Quick Menu</span>
                <div class="quick-menu">
                    <ul class="mt-3">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Service</a></li>
                        <li><a href="">Team</a></li>
                        <li><a href="">Gallery</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="footcont">
                    <span class="text-white border-bottom">Contact Us</span>
                    <ul class="mt-3">
                        <li class="mb-2"><i class="fa fa-map-marker"></i> <?php echo e($company->address); ?> </li>
                        <li class="mb-2"><i class="fa fa-phone"></i> <?php echo e($company->phone); ?> </li>
                        <li class="mb-2"><i class="far fa-envelope-open"></i> <?php echo e($company->email); ?></li>
                    </ul>
                    <ul class="socialfoot d-flex justify-content-start mt-2">
                        <li><a class="" href="<?php echo e($company->facebook); ?>" title="facebook" target="_blank"><i class="bi bi-facebook"></i></a></li>
                        <li class="pl-2"><a class="" href="<?php echo e($company->twitter); ?>" title="twitter" target="_blank"><i class="bi bi-twitter"></i></a></li>
                        <li class="pl-2"><a class="" href="<?php echo e($company->linkedin); ?>" title="linkedin" target="_blank"><i class="bi bi-linkedin"></i></a></li>
                        <li class="pl-2"><a class="" href="<?php echo e($company->instagram); ?>" title="instagram" target="_blank"><i class="bi bi-instagram"></i></a></li>
                        <li class="pl-2"><a class="" href="mailto:<?php echo e($company->email); ?>" title="envelope" target="_blank"><i class="bi bi-envelope"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <span class="text-white border-bottom">Subscribe to our newsletter</span>
                <form method="POST" action="<?php echo e(route('subscriber.store')); ?>" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <div class="form-group subscribe">
                        <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter Email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button class="btn btn-outline-info mt-2" type="submit">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div id="fb-root"></div>
    <script>
        window.fbAsyncInit = function() {
            FB.init({
            xfbml            : true,
            version          : 'v10.0'
            });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>
        <!-- Your Chat Plugin code -->
    <div class="fb-customerchat" attribution="setup_tool" page_id="100782558732238">
    </div>
</section>
<!-- footer area end -->
<!-- footer bottom start -->
<section class="foot-botttom border-top">
    <div class="container">
        <div class="clearfix">
            <div class="float-md-left text-center">
                Copyright <?php echo e(date('Y')); ?> © ZealtechStudio
            </div>
            
        </div>
    </div>

    <!-- Load Facebook SDK for JavaScript -->
</section>

<?php /**PATH C:\laragon\www\zealtech\resources\views/partials/footer.blade.php ENDPATH**/ ?>