
<?php $__env->startSection('title', 'Pages Edit'); ?>
<?php $__env->startPush('admin-css'); ?>
<link href="<?php echo e(asset('summernote/summernote-bs4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>    
<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="form-area">
                    <div class="d-flex justify-content-between heading">
                        <h4 class=""><i class="fa fa-edit"></i> Edit Page</h4>
                        <div>
                            <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-primary btn-sm overflow-hidden">page list</a>
                        </div>
                    </div>
                    <form action="<?php echo e(route('pages.update',$page->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label for="name">Menu Name <span class="text-danger"> * </span></label>
                                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" type="text" name="name" value="<?php echo e($page->name); ?>" placeholder="Enter name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="title">Page Title <span class="text-danger"> * </span></label>
                                <input class="form-control" id="title" type="text" name="title" value="<?php echo e($page->title); ?>" placeholder="Enter Page title">
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="sub_title">Page Sub Title <span class="text-danger"> * </span></label>
                                <input class="form-control" id="sub_title" type="text" name="sub_title" value="<?php echo e($page->sub_title); ?>" placeholder="Enter Sub title">
                            </div>
                            <div class="col-md-12 mb-2">
                                <label for="summernote">Page Content </label>
                                <textarea name="content" id="summernote"><?php echo e($page->content); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="clearfix mt-1">
                            <div class="float-md-left">
                                <button type="submit" class="btn btn-info">Update</button>
                                <button type="reset" class="btn btn-dark">Reset</button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('summernote/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernote').summernote({
        tabsize: 2,
        height: 200
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zealtech\resources\views/adminpages/newPage/edit.blade.php ENDPATH**/ ?>