
<?php $__env->startSection('title', 'Team Member'); ?>
<?php $__env->startSection('user-content'); ?>
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Our Team</h2>
            <ol>
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li>Team</li>
            </ol>
        </div>
    </div>
</section>
<section id="team" class="team section-bg">
    <div class="container">
        <div class="section-title">
            <h2>Team</h2>
            <p>Our Expart & Professional Team Member</p>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                    <div class="member">
                        <div class="member-img">
                            <img src="<?php echo e($member->image); ?>" class="img-fluid" alt="" />
                            <div class="social">
                                <a href="<?php echo e($member->twitter); ?>" target="_blank"><i class="bi bi-twitter"></i></a>
                                <a href="<?php echo e($member->facebook); ?>" target="_blank"><i class="bi bi-facebook"></i></a>
                                <a href="<?php echo e($member->instagram); ?>" target="_blank"><i class="bi bi-instagram"></i></a>
                                <a href="<?php echo e($member->linkedin); ?>" target="_blank"><i class="bi bi-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="member-info">
                            <h4><?php echo e($member->name); ?></h4>
                            <span><?php echo e($member->designation); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                    <div class="member" data-aos="fade-up" data-aos-delay="100">
                        <div class="member-img">
                            <img src="img/team/team-1.jpg" class="img-fluid" alt="" />
                            <div class="social">
                                <a href=""><i class="bi bi-twitter"></i></a>
                                <a href=""><i class="bi bi-facebook"></i></a>
                                <a href=""><i class="bi bi-instagram"></i></a>
                                <a href=""><i class="bi bi-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="member-info">
                            <h4>Walter White</h4>
                            <span>Chief Executive Officer</span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zealtech\resources\views/pages/team.blade.php ENDPATH**/ ?>