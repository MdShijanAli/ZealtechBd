<section class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="footcont ">
                    <h3 class="text-light">ZealtechStudio</h3>
                    <p class="pt-2 text-white"> {{ $company->about }} </p>
                </div>
            </div>
            <div class="col-md-2 col-sm-6 mb-4">
                <span class="text-white border-bottom">Quick Menu</span>
                <div class="quick-menu">
                    <ul class="mt-3">
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Service</a></li>
                        <li><a href="">Team</a></li>
                        <li><a href="">Gallery</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="footcont">
                    <span class="text-white border-bottom">Contact Us</span>
                    <ul class="mt-3">
                        <li class="mb-2"><i class="fa fa-map-marker"></i> {{ $company->address }} </li>
                        <li class="mb-2"><i class="fa fa-phone"></i> {{ $company->phone }} </li>
                        <li class="mb-2"><i class="far fa-envelope-open"></i> {{ $company->email }}</li>
                    </ul>
                    <ul class="socialfoot d-flex justify-content-start mt-2">
                        <li><a class="" href="{{ $company->facebook }}" title="facebook" target="_blank"><i class="bi bi-facebook"></i></a></li>
                        <li class="pl-2"><a class="" href="{{ $company->twitter }}" title="twitter" target="_blank"><i class="bi bi-twitter"></i></a></li>
                        <li class="pl-2"><a class="" href="{{ $company->linkedin }}" title="linkedin" target="_blank"><i class="bi bi-linkedin"></i></a></li>
                        <li class="pl-2"><a class="" href="{{ $company->instagram }}" title="instagram" target="_blank"><i class="bi bi-instagram"></i></a></li>
                        <li class="pl-2"><a class="" href="mailto:{{ $company->email }}" title="envelope" target="_blank"><i class="bi bi-envelope"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-4">
                <span class="text-white border-bottom">Subscribe to our newsletter</span>
                <form method="POST" action="{{ route('subscriber.store') }}" class="mt-3">
                    @csrf
                    <div class="form-group subscribe">
                        <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" placeholder="Enter Email">
                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                        <button class="btn btn-outline-info mt-2" type="submit">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    {{-- messangers --}}
    <div id="fb-root"></div>
    <script>
        window.fbAsyncInit = function() {
            FB.init({
            xfbml            : true,
            version          : 'v10.0'
            });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>
        <!-- Your Chat Plugin code -->
    <div class="fb-customerchat" attribution="setup_tool" page_id="100782558732238">
    </div>
</section>
<!-- footer area end -->
<!-- footer bottom start -->
<section class="foot-botttom border-top">
    <div class="container">
        <div class="clearfix">
            <div class="float-md-left text-center">
                Copyright {{ date('Y') }} © ZealtechStudio
            </div>
            {{-- <div class="float-md-right text-center">
                Develop By - <a href=""> Link-up Technology</a>
            </div> --}}
        </div>
    </div>

    <!-- Load Facebook SDK for JavaScript -->
</section>

